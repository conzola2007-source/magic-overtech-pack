# Magic Overtech pre-launch (runs from the instance's .minecraft folder, before every launch).
# 1. Once only: copy the player's own settings from their old CurseForge Overtech instance.
# 2. Every time: pull pack updates with packwiz.
# Copied settings are the files the pack marks "preserve", so updates never overwrite them.
param([string]$Java)

$PackUrl = 'https://conzola2007-source.github.io/magic-overtech-pack/pack.toml'
$Here = (Get-Location).Path
$Marker = Join-Path $Here '.settings-imported'

if (-not (Test-Path $Marker)) {
    try {
        $roots = @("$env:USERPROFILE\curseforge\minecraft\Instances")
        $old = Get-ChildItem $roots -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match 'overtech' -and (Test-Path (Join-Path $_.FullName 'options.txt')) } |
            Sort-Object { (Get-Item (Join-Path $_.FullName 'options.txt')).LastWriteTime } -Descending |
            Select-Object -First 1
        if ($old) {
            Write-Output "Bringing your settings over from CurseForge: $($old.Name)"
            $src = $old.FullName
            # Single files: keybinds, video, sound (options.txt) and graphics/shader settings.
            foreach ($f in 'options.txt', 'config\oculus.properties', 'config\embeddium-options.json', 'config\sodium-extra-options.json') {
                $p = Join-Path $src $f
                if (Test-Path $p) {
                    $d = Join-Path $Here $f
                    New-Item -ItemType Directory -Force (Split-Path $d) | Out-Null
                    Copy-Item $p $d -Force
                    Write-Output "  $f"
                }
            }
            # Shader option files, and any resource or shader packs they added themselves.
            foreach ($dir in 'shaderpacks', 'resourcepacks') {
                $s = Join-Path $src $dir
                if (-not (Test-Path $s)) { continue }
                $d = Join-Path $Here $dir
                New-Item -ItemType Directory -Force $d | Out-Null
                Get-ChildItem $s -File | ForEach-Object {
                    $t = Join-Path $d $_.Name
                    if ($_.Name -match '\.bak$|\.before-') { return }
                    if ($_.Name -like '*.txt' -or -not (Test-Path $t)) { Copy-Item $_.FullName $t -Force; Write-Output "  $dir\$($_.Name)" }
                }
            }
            # Folders the pack never touches: JEI bookmarks, voice chat settings, single player worlds, screenshots, schematics.
            foreach ($dir in 'config\jei', 'config\voicechat', 'saves', 'screenshots', 'schematics') {
                $s = Join-Path $src $dir
                if (Test-Path $s) {
                    $d = Join-Path $Here $dir
                    New-Item -ItemType Directory -Force $d | Out-Null
                    Copy-Item (Join-Path $s '*') $d -Recurse -Force
                    Write-Output "  $dir"
                }
            }
            $vc = Join-Path $src 'config\voicechat-client.toml'
            if (Test-Path $vc) { Copy-Item $vc (Join-Path $Here 'config\voicechat-client.toml') -Force }
        } else {
            Write-Output 'No old CurseForge Overtech instance found, starting with the pack defaults.'
        }
    } catch {
        Write-Output "Could not bring settings over (the game still starts): $_"
    }
    Set-Content $Marker (Get-Date -Format s)
}

# Prism passes javaw.exe, which PowerShell would not wait for; use java.exe beside
# it, and pipe the output so the update finishes before the game starts.
$cli = Join-Path (Split-Path $Java) 'java.exe'
if (Test-Path $cli) { $Java = $cli }
& $Java -jar packwiz-installer-bootstrap.jar $PackUrl | ForEach-Object { $_ }
exit $LASTEXITCODE
